# IPL-2019
Yes, we are talking about IPL - Indian Premier League (India's Cricket Festival). The 2019 season of the Indian Premier League, also known as IPL 12, will be the twelfth season of the IPL. The tournament will start on 23 March and take place entirely in India. 

India's opening match at the 2019 Cricket World Cup was postponed from 2 to 5 June as the BCCI were directed to maintain a mandatory 15-day gap between the conclusion of IPL and India's subsequent international fixture. All teams will play a minimum of 4 matches while Delhi Capitals (previously known as Delhi Daredevils) and Royal Challengers Bangalore will play 5 matches. Similarly, all teams will play two home and two away matches while DC will play three home matches and RCB will play three away matches. 

We have covered the basic analysis from IPL 2008 to IPL 2018.

1. Number of matches each season
2. Number of matches in each venue
3. Number of matches played by each team
4. Number of wins per team
5. Champions each season
6. Top players of the match
7. Top Umpires
8. How lucky are the toss winning teams?
9. Batsman analysis
10. Number of 6's
11. Batsman who has played the most number of dot balls.
12. Most common dismissal types in IPL

What Next: 

Match result prediction!?


